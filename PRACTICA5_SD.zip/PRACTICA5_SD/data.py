data = [{ 'DNI': '70398195', 'USUARIO': 'Sofia Bobadilla', 'Reserva': 1, 'Gate': 1, 'time': '9:00 pm', 'day': '11/11/2023'},
        { 'DNI': '78371283', 'USUARIO': 'Carlos Oliva', 'Reserva': 0, 'Gate':0},
        { 'DNI': '74502041', 'USUARIO': 'Jhon Rossel', 'Reserva': 1, 'Gate':2, 'time': '8:00 pm', 'day': '10/11/2023'},
        ]

times = [{'day': '10/11/2023', 'times': [{'time': '8:00 pm', 'gates':[{'gate': 1, 'reserva': 0}, {'gate': 2, 'reserva': 1}]}, {'time': '9:00 pm','gates':[{'gate': 1, 'reserva': 0}, {'gate': 2, 'reserva': 1}]}]},
         {'day': '11/11/2023', 'times': [{'time': '8:00 pm', 'gates':[{'gate': 1, 'reserva': 1}, {'gate': 2, 'reserva': 0}]}, {'time': '9:00 pm','gates':[{'gate': 1, 'reserva': 1}, {'gate': 2, 'reserva': 0}]}]},
        ]